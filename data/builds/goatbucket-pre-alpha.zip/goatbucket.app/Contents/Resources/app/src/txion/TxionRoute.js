import React, {Component} from 'react';
import Txion from './Txion'

export default function TxionRoute(props) {
  return (
    <div>
      <Txion />
    </div>
  );
}
