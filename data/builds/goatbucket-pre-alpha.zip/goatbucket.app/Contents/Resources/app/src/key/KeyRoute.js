import React from 'react';
import Key from './Key'

export default function KeyRoute(props) {
  return (
    <div>
      <Key />
    </div>
  );
}
