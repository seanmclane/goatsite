import React, {Component} from 'react';

export default function Test(props) {
  return (
    <div>
      <h1>TEST</h1>
    </div>
  );
}
