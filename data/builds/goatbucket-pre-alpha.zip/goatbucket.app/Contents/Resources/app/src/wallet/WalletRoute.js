import React, {Component} from 'react';
import Wallet from './Wallet'

export default function WalletRoute(props) {
  return (
    <div>
      <Wallet />
    </div>
  );
}
