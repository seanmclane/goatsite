import React from 'react';
import Guide from './Guide'

export default function GuideRoute(props) {
  return (
    <div>
      <Guide />
    </div>
  );
}